# P2P_BitTorrent
John Mone
Jiawei Weng
Darren Wang

Progress done:
Handshake class completed
Connection established between multiple peers
General idea understood

To be done
Sending information
Working on the actual functions of BitTorrent (unchoking, optimistic unchoking)