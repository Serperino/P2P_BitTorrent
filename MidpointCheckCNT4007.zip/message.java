
//May use this eventually,

public class message {
    private int length;
    private char type;
    private byte[] payload;

 // Getters
public int getLength() {
    return length;
}





public void setLength(int length) {
    this.length = length;
}





public char getType() {
    return type;
}





public void setType(char type) {
    this.type = type;
}





public byte[] getPayload() {
    return payload;
}





public void setPayload(byte[] payload) {
    this.payload = payload;
}
    


    


}
